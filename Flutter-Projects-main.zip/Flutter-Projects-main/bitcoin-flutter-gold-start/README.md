
# Bitcoin Ticker 🤑

This is a crypto currency price checking app. By the end of the module, you'll be able to monitor your bitcoin investents on the move!

![Finished App](https://github.com/londonappbrewery/Images/blob/master/bitcoin-flutter-demo.gif)

