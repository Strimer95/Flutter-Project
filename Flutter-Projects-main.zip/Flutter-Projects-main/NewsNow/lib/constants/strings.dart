class StringConstants {
  static var apiKey = 'b58619393039413f9aed95ac690278ff';
  static var url =
      'http://newsapi.org/v2/everything?domains=wsj.com&apiKey=$apiKey';
}
