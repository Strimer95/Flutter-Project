package com.example.NewsNow

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
