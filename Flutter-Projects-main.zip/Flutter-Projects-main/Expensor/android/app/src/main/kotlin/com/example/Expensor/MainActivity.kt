package com.example.Expensor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
