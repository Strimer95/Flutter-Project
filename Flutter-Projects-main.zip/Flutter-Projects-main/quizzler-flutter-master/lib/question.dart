class Question {
  String questionText;
  bool questionAns;

  Question(String q, bool a) {
    questionText = q;
    questionAns = a;
  }
}
