

# Xylophone 🎹

This is a music app that plays Xylophone sounds. For every Beethoven out there, this will let you unleash your musical talent where ever you are. 

![Finished App](https://github.com/londonappbrewery/Images/blob/master/xylophone-flutter.png)

