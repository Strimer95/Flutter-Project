
# Flash Chat ⚡️

## Our Goal

This is a modern messaging app where users can sign up and log in to chat.

![Finished App](https://github.com/londonappbrewery/Images/blob/master/flash_chat_flutter_demo.gif)

