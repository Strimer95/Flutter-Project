

# BMI Calculator 💪

This is a Body Mass Index Calculator inspired by the beautiful designs made by [Ruben Vaalt](https://dribbble.com/shots/4585382-Simple-BMI-Calculator). It will be a multi screen app with simple functionality but full-on custom styling. 

![Finished App](https://github.com/londonappbrewery/Images/blob/master/bmi-calc-demo.gif)

